#!/usr/bin/env

python3 server.py &
python3 app.py &