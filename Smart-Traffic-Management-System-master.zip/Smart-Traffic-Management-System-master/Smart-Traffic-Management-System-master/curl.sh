#!/usr/bin/env

curl http://localhost:3000/inf &
curl http://localhost:4000/api &